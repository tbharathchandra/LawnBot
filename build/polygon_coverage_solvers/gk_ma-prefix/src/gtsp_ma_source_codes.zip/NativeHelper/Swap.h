#include <stdlib.h>
#include "NativeHelper.h"

int FullSwap(int *solution);
int NeighbourSwapWithCO(int *solution);
int ThreeNeighbourFullSwap(int *solution);
int FourNeighbourFullSwap(int *solution);

