extern "C" 
{
	__declspec(dllexport) int InsertsWithCO(int *solution);
}
