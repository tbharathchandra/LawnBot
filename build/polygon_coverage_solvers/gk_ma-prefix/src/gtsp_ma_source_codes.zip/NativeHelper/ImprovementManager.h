extern "C" 
{
	__declspec(dllexport) int Improve(int *solution, int oldLen);
}

