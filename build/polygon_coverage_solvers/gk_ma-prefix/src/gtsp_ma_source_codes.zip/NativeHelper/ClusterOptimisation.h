extern "C"
{
	__declspec(dllexport) int ClusterOptimisation(int *solution);
}