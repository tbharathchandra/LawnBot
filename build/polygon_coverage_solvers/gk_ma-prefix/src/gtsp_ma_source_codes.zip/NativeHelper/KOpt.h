int DirectTwoOptSym(int *solution);
int DirectTwoOptAsym(int *solution);
int TwoOptFullSym(int *solution);
int TwoOptFullAsym(int *solution);
